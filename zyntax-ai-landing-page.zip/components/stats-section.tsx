"use client"

import { motion } from "framer-motion"
import { Zap, Users, Clock } from "lucide-react"

const stats = [
  {
    icon: Zap,
    value: "10K+",
    label: "AI Generations",
    color: "purple",
  },
  {
    icon: Users,
    value: "5K+",
    label: "Active Users",
    color: "blue",
  },
  {
    icon: Clock,
    value: "99.9%",
    label: "Uptime",
    color: "cyan",
  },
]

export function StatsSection() {
  return (
    <section className="relative py-24">
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="relative"
        >
          {/* Glow background */}
          <div className="absolute -inset-4 rounded-3xl bg-gradient-to-r from-purple-500/10 via-blue-500/10 to-cyan-500/10 blur-xl" />

          <div className="glass-card relative overflow-hidden rounded-3xl p-8 md:p-12">
            <div className="grid gap-8 md:grid-cols-3">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="text-center"
                >
                  <StatItem stat={stat} />
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

function StatItem({ stat }: { stat: (typeof stats)[0] }) {
  const Icon = stat.icon
  const colorClasses = {
    purple: "from-purple-500 to-violet-500 text-purple-400",
    blue: "from-blue-500 to-cyan-500 text-blue-400",
    cyan: "from-cyan-500 to-teal-500 text-cyan-400",
  }

  return (
    <div className="flex flex-col items-center">
      <div className={`mb-4 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${colorClasses[stat.color as keyof typeof colorClasses].split(" ")[0]} ${colorClasses[stat.color as keyof typeof colorClasses].split(" ")[1]}`}>
        <Icon className="h-7 w-7 text-white" />
      </div>
      <div className="text-4xl font-bold text-foreground md:text-5xl">{stat.value}</div>
      <div className="mt-2 text-muted-foreground">{stat.label}</div>
    </div>
  )
}
