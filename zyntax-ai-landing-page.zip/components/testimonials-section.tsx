"use client"

import { motion } from "framer-motion"
import { Star } from "lucide-react"

const testimonials = [
  {
    name: "Sarah Chen",
    role: "Content Creator",
    avatar: "SC",
    content: "Zyntax AI has completely transformed my content workflow. I&apos;m creating 3x more content in half the time. The captions it generates are incredibly engaging!",
    rating: 5,
  },
  {
    name: "Marcus Johnson",
    role: "E-commerce Owner",
    avatar: "MJ",
    content: "The product descriptions are spot-on every time. My conversion rates have increased by 40% since I started using Zyntax for all my listings.",
    rating: 5,
  },
  {
    name: "Emma Williams",
    role: "Marketing Manager",
    avatar: "EW",
    content: "Our ad copy performance has never been better. Zyntax AI understands our brand voice perfectly and delivers consistent, high-converting content.",
    rating: 5,
  },
]

export function TestimonialsSection() {
  return (
    <section className="relative py-24">
      {/* Background elements */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute bottom-0 left-1/4 h-64 w-64 rounded-full bg-blue-500/10 blur-3xl" />
        <div className="absolute right-1/4 top-0 h-64 w-64 rounded-full bg-purple-500/10 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <span className="mb-4 inline-block rounded-full border border-cyan-500/30 bg-cyan-500/10 px-4 py-1.5 text-sm text-cyan-300">
            Testimonials
          </span>
          <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl lg:text-5xl text-balance">
            Loved by{" "}
            <span className="gradient-text">creators worldwide</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground text-pretty">
            See what our users have to say about their experience with Zyntax AI.
          </p>
        </motion.div>

        {/* Testimonials grid */}
        <div className="mt-16 grid gap-8 md:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <TestimonialCard testimonial={testimonial} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

function TestimonialCard({ testimonial }: { testimonial: (typeof testimonials)[0] }) {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="group relative h-full"
    >
      {/* Glow effect on hover */}
      <div className="absolute -inset-0.5 rounded-2xl bg-gradient-to-r from-purple-500/30 to-blue-500/30 opacity-0 blur transition-opacity duration-300 group-hover:opacity-100" />

      <div className="glass-card relative h-full rounded-2xl p-6">
        {/* Rating */}
        <div className="mb-4 flex gap-1">
          {Array.from({ length: testimonial.rating }).map((_, i) => (
            <Star key={i} className="h-4 w-4 fill-yellow-500 text-yellow-500" />
          ))}
        </div>

        {/* Content */}
        <p className="mb-6 text-sm text-muted-foreground leading-relaxed">
          {testimonial.content}
        </p>

        {/* Author */}
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-blue-500 text-sm font-semibold text-white">
            {testimonial.avatar}
          </div>
          <div>
            <div className="font-medium text-foreground">{testimonial.name}</div>
            <div className="text-xs text-muted-foreground">{testimonial.role}</div>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
