"use client"

import { motion } from "framer-motion"
import { MessageSquare, ShoppingBag, User, Megaphone } from "lucide-react"

const features = [
  {
    icon: MessageSquare,
    title: "Caption Generator",
    description: "Create engaging social media captions that drive likes, comments, and shares.",
    gradient: "from-purple-500 to-violet-500",
  },
  {
    icon: ShoppingBag,
    title: "Product Description Generator",
    description: "Write compelling product descriptions that convert browsers into buyers.",
    gradient: "from-blue-500 to-cyan-500",
  },
  {
    icon: User,
    title: "AI Bio Creator",
    description: "Craft professional bios for any platform that showcase your unique personality.",
    gradient: "from-cyan-500 to-teal-500",
  },
  {
    icon: Megaphone,
    title: "Ad Copy Generator",
    description: "Generate high-converting ad copy for Facebook, Google, and Instagram ads.",
    gradient: "from-pink-500 to-purple-500",
  },
]

export function FeaturesSection() {
  return (
    <section id="features" className="relative py-24">
      {/* Background elements */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute left-1/4 top-1/4 h-64 w-64 rounded-full bg-purple-500/10 blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 h-64 w-64 rounded-full bg-blue-500/10 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <span className="mb-4 inline-block rounded-full border border-purple-500/30 bg-purple-500/10 px-4 py-1.5 text-sm text-purple-300">
            Features
          </span>
          <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl lg:text-5xl text-balance">
            Everything you need to{" "}
            <span className="gradient-text">create content</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground text-pretty">
            Powerful AI tools designed to help you create engaging content faster than ever before.
          </p>
        </motion.div>

        {/* Features grid */}
        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <FeatureCard feature={feature} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

function FeatureCard({ feature }: { feature: (typeof features)[0] }) {
  const Icon = feature.icon

  return (
    <motion.div
      whileHover={{ y: -5, scale: 1.02 }}
      className="group relative h-full"
    >
      {/* Glow effect on hover */}
      <div className="absolute -inset-0.5 rounded-2xl bg-gradient-to-r from-purple-500/50 to-blue-500/50 opacity-0 blur transition-opacity duration-300 group-hover:opacity-100" />
      
      <div className="glass-card relative h-full rounded-2xl p-6">
        {/* Icon */}
        <div className={`mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${feature.gradient}`}>
          <Icon className="h-6 w-6 text-white" />
        </div>

        {/* Content */}
        <h3 className="mb-2 text-lg font-semibold text-foreground">{feature.title}</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>

        {/* Hover arrow */}
        <div className="mt-4 flex items-center text-sm font-medium text-purple-400 opacity-0 transition-opacity group-hover:opacity-100">
          Learn more
          <svg className="ml-1 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>
    </motion.div>
  )
}
