"use client"

import { motion } from "framer-motion"
import { Zap, Sparkles, Globe, Users } from "lucide-react"

const features = [
  {
    icon: Zap,
    title: "Fast AI Generation",
    description: "Generate high-quality captions and copy instantly.",
    gradient: "from-purple-500 to-blue-500",
  },
  {
    icon: Sparkles,
    title: "Premium Outputs",
    description: "Human-like content optimized for engagement and conversions.",
    gradient: "from-blue-500 to-cyan-500",
  },
  {
    icon: Globe,
    title: "Multi-Platform Support",
    description: "Content for Instagram, Facebook, LinkedIn, Shopify, YouTube, and more.",
    gradient: "from-cyan-500 to-purple-500",
  },
  {
    icon: Users,
    title: "Beginner Friendly",
    description: "Simple UI designed for creators, students, freelancers, and businesses.",
    gradient: "from-purple-500 to-pink-500",
  },
]

export function WhyChooseSection() {
  return (
    <section id="about" className="relative py-28 lg:py-36">
      {/* Background elements */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute right-1/4 top-1/3 h-[500px] w-[500px] rounded-full bg-purple-500/10 blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 h-[400px] w-[400px] rounded-full bg-blue-500/10 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-20 text-center"
        >
          <span className="mb-6 inline-block rounded-full border border-purple-500/30 bg-purple-500/10 px-5 py-2 text-sm font-medium text-purple-300">
            Why Zyntax AI
          </span>
          <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl lg:text-5xl text-balance">
            Why Creators Choose{" "}
            <span className="gradient-text">Zyntax AI</span>
          </h2>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground text-pretty leading-relaxed">
            Join thousands of creators who trust Zyntax AI to power their content strategy.
          </p>
        </motion.div>

        {/* Feature cards grid */}
        <div className="grid gap-8 md:grid-cols-2 lg:gap-10">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group relative"
            >
              {/* Glow background */}
              <div className={`absolute -inset-1 rounded-3xl bg-gradient-to-r ${feature.gradient} opacity-0 blur-xl transition-opacity duration-500 group-hover:opacity-30`} />
              
              {/* Card */}
              <div className="glass-card relative h-full rounded-3xl p-8 transition-all duration-300 hover:border-purple-500/50 lg:p-10">
                {/* Icon container */}
                <div className={`mb-6 inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br ${feature.gradient} shadow-lg shadow-purple-500/20`}>
                  <feature.icon className="h-8 w-8 text-white" />
                </div>

                {/* Content */}
                <h3 className="mb-3 text-xl font-bold text-foreground lg:text-2xl">
                  {feature.title}
                </h3>
                <p className="text-base text-muted-foreground leading-relaxed lg:text-lg">
                  {feature.description}
                </p>

                {/* Decorative corner gradient */}
                <div className={`pointer-events-none absolute bottom-0 right-0 h-32 w-32 rounded-br-3xl bg-gradient-to-tl ${feature.gradient} opacity-5`} />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-20 text-center"
        >
          <a
            href="#pricing"
            className="group relative inline-flex items-center justify-center gap-2 overflow-hidden rounded-full bg-gradient-to-r from-purple-500 to-blue-500 px-8 py-4 text-base font-semibold text-white shadow-lg shadow-purple-500/30 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/40"
          >
            <span className="absolute inset-0 bg-gradient-to-r from-purple-600 to-blue-600 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
            <span className="relative flex items-center gap-2">
              <Sparkles className="h-5 w-5" />
              Start Creating for Free
            </span>
          </a>
        </motion.div>
      </div>
    </section>
  )
}
