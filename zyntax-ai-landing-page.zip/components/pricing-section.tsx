"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Check, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"

const plans = [
  {
    name: "Free",
    description: "Perfect for getting started with AI content",
    price: { monthly: 0, yearly: 0 },
    features: [
      "20 AI generations per day",
      "Caption Generator",
      "Product Description Generator",
      "Basic AI Bio Creator",
      "Standard templates",
      "Community support",
    ],
    cta: "Start Free",
    popular: false,
  },
  {
    name: "Pro",
    description: "For creators who need unlimited power",
    price: { monthly: 9, yearly: 86 },
    features: [
      "Unlimited AI generations",
      "Advanced caption tools",
      "Premium product descriptions",
      "AI Ad Copy Generator",
      "Premium templates",
      "Save history",
      "Faster generation speed",
      "Priority support",
    ],
    cta: "Upgrade to Pro",
    popular: true,
  },
  {
    name: "Business",
    description: "For teams and growing businesses",
    price: { monthly: 15, yearly: 144 },
    features: [
      "Everything in Pro",
      "Team collaboration",
      "Bulk content generation",
      "Export to Word/PDF",
      "API access",
      "Brand voice customization",
      "Analytics dashboard",
      "Premium support",
    ],
    cta: "Start Business",
    popular: false,
  },
]

export function PricingSection() {
  const [isYearly, setIsYearly] = useState(false)

  return (
    <section id="pricing" className="relative py-28 lg:py-36">
      {/* Background glow elements */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute left-1/4 top-1/4 h-[500px] w-[500px] -translate-x-1/2 rounded-full bg-purple-600/15 blur-[120px]" />
        <div className="absolute right-1/4 bottom-1/4 h-[400px] w-[400px] translate-x-1/2 rounded-full bg-blue-600/15 blur-[100px]" />
        <div className="absolute left-1/2 top-1/2 h-[300px] w-[300px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan-500/10 blur-[80px]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-purple-500/30 bg-purple-500/10 px-4 py-1.5 text-sm text-purple-300">
            <Sparkles className="h-4 w-4" />
            Pricing
          </span>
          <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl lg:text-5xl text-balance">
            Simple, transparent{" "}
            <span className="gradient-text">pricing</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground text-pretty">
            Start free and scale as you grow. No hidden fees, cancel anytime.
          </p>

          {/* Toggle */}
          <div className="mt-10 flex items-center justify-center gap-4">
            <span className={`text-sm font-medium transition-colors ${!isYearly ? "text-foreground" : "text-muted-foreground"}`}>
              Monthly
            </span>
            <button
              onClick={() => setIsYearly(!isYearly)}
              className="relative h-8 w-16 rounded-full bg-secondary/80 border border-border/50 transition-all hover:border-purple-500/30"
            >
              <motion.div
                className="absolute top-1 h-6 w-6 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 shadow-lg shadow-purple-500/30"
                animate={{ left: isYearly ? "calc(100% - 1.75rem)" : "0.25rem" }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              />
            </button>
            <span className={`flex items-center gap-2 text-sm font-medium transition-colors ${isYearly ? "text-foreground" : "text-muted-foreground"}`}>
              Yearly
              <span className="rounded-full bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30 px-2.5 py-0.5 text-xs font-semibold text-green-400">
                Save 20%
              </span>
            </span>
          </div>
        </motion.div>

        {/* Pricing cards */}
        <div className="mt-16 grid gap-6 lg:grid-cols-3 lg:gap-8">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              className="flex"
            >
              <PricingCard plan={plan} isYearly={isYearly} />
            </motion.div>
          ))}
        </div>

        {/* Trust badge */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6 }}
          className="mt-12 text-center text-sm text-muted-foreground"
        >
          Trusted by 5,000+ creators and businesses worldwide
        </motion.p>
      </div>
    </section>
  )
}

function PricingCard({ plan, isYearly }: { plan: (typeof plans)[0]; isYearly: boolean }) {
  const price = isYearly ? plan.price.yearly : plan.price.monthly

  return (
    <motion.div
      whileHover={{ y: -8, scale: 1.02 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className={`relative w-full ${plan.popular ? "z-10" : ""}`}
    >
      {/* Popular badge */}
      {plan.popular && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-20">
          <div className="rounded-full bg-gradient-to-r from-purple-500 to-blue-500 px-5 py-1.5 text-sm font-semibold text-white shadow-lg shadow-purple-500/30">
            Most Popular
          </div>
        </div>
      )}

      {/* Animated glow effect for popular plan */}
      {plan.popular && (
        <div className="absolute -inset-1 rounded-3xl bg-gradient-to-r from-purple-500 via-blue-500 to-cyan-500 opacity-60 blur-lg animate-pulse" />
      )}

      {/* Floating glow behind card */}
      <div className={`absolute inset-0 rounded-3xl ${plan.popular ? "bg-purple-500/20" : "bg-purple-500/5"} blur-2xl transition-opacity duration-500`} />

      <div className={`glass-card relative h-full w-full rounded-3xl p-8 lg:p-10 ${
        plan.popular 
          ? "border-purple-500/50 bg-gradient-to-b from-purple-500/10 to-transparent" 
          : "hover:border-purple-500/30"
      } transition-all duration-300`}>
        {/* Plan header */}
        <div className="mb-8">
          <h3 className="text-2xl font-bold text-foreground">{plan.name}</h3>
          <p className="mt-2 text-sm text-muted-foreground">{plan.description}</p>
        </div>

        {/* Price */}
        <div className="mb-8">
          <div className="flex items-baseline gap-1">
            <span className="text-5xl font-bold tracking-tight text-foreground lg:text-6xl">
              ${price}
            </span>
            {price > 0 && (
              <span className="text-lg text-muted-foreground">
                /{isYearly ? "year" : "month"}
              </span>
            )}
          </div>
          {price === 0 && (
            <p className="mt-2 text-sm text-muted-foreground">Free forever</p>
          )}
          {isYearly && price > 0 && (
            <p className="mt-2 text-sm text-green-400">
              ${Math.round(price / 12)}/month billed annually
            </p>
          )}
        </div>

        {/* Features */}
        <ul className="mb-10 space-y-4">
          {plan.features.map((feature) => (
            <li key={feature} className="flex items-start gap-3 text-sm">
              <div className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full ${
                plan.popular 
                  ? "bg-gradient-to-r from-purple-500 to-blue-500 shadow-lg shadow-purple-500/30" 
                  : "bg-purple-500/20"
              }`}>
                <Check className={`h-3 w-3 ${plan.popular ? "text-white" : "text-purple-400"}`} />
              </div>
              <span className="text-muted-foreground">{feature}</span>
            </li>
          ))}
        </ul>

        {/* CTA */}
        <Button
          size="lg"
          className={`w-full h-14 text-base font-semibold transition-all duration-300 ${
            plan.popular
              ? "bg-gradient-to-r from-purple-500 to-blue-500 text-white shadow-lg shadow-purple-500/30 hover:shadow-xl hover:shadow-purple-500/40 hover:from-purple-600 hover:to-blue-600"
              : "border-border/50 bg-secondary/50 text-foreground hover:bg-secondary hover:border-purple-500/30 hover:shadow-lg hover:shadow-purple-500/10"
          }`}
          variant={plan.popular ? "default" : "outline"}
        >
          {plan.cta}
        </Button>
      </div>
    </motion.div>
  )
}
