"use client"

import { motion } from "framer-motion"
import { Sparkles, Hash, BarChart3, Settings, Send, Copy, RefreshCw } from "lucide-react"

export function DashboardPreview() {
  return (
    <div className="relative">
      <div className="glass-card animate-float overflow-hidden rounded-2xl p-1 glow-purple">
        <div className="rounded-xl bg-background/80 p-4">
          {/* Dashboard Header */}
          <div className="mb-4 flex items-center justify-between border-b border-border pb-4">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-purple-500 to-blue-500">
                <Sparkles className="h-4 w-4 text-white" />
              </div>
              <span className="font-semibold text-foreground">Zyntax AI</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-green-500" />
              <span className="text-xs text-muted-foreground">Connected</span>
            </div>
          </div>

          <div className="flex gap-4">
            {/* Sidebar */}
            <div className="hidden w-40 shrink-0 space-y-2 border-r border-border pr-4 sm:block">
              <SidebarItem icon={<Sparkles className="h-4 w-4" />} label="Caption Gen" active />
              <SidebarItem icon={<Hash className="h-4 w-4" />} label="Hashtags" />
              <SidebarItem icon={<BarChart3 className="h-4 w-4" />} label="Analytics" />
              <SidebarItem icon={<Settings className="h-4 w-4" />} label="Settings" />
            </div>

            {/* Main content */}
            <div className="flex-1 space-y-4">
              {/* Input area */}
              <div className="space-y-2">
                <label className="text-xs font-medium text-muted-foreground">Topic or Product</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Wireless earbuds launch..."
                    className="flex-1 rounded-lg border border-border bg-input px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                    defaultValue="Summer collection drop"
                  />
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-purple-500 to-blue-500 px-4 py-2 text-sm font-medium text-white"
                  >
                    <Send className="h-4 w-4" />
                  </motion.button>
                </div>
              </div>

              {/* Generated output */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-medium text-muted-foreground">Generated Caption</label>
                  <div className="flex gap-1">
                    <button className="rounded p-1 text-muted-foreground hover:bg-secondary hover:text-foreground">
                      <Copy className="h-3 w-3" />
                    </button>
                    <button className="rounded p-1 text-muted-foreground hover:bg-secondary hover:text-foreground">
                      <RefreshCw className="h-3 w-3" />
                    </button>
                  </div>
                </div>
                <div className="rounded-lg border border-purple-500/30 bg-purple-500/5 p-3 text-sm text-foreground">
                  <p>{"✨ Summer just got an upgrade! Our new collection is HERE and it's giving everything you need for the season. Fresh styles, bold colors, limited drops. Don't sleep on this one! 🔥"}</p>
                </div>
              </div>

              {/* Hashtags */}
              <div className="space-y-2">
                <label className="text-xs font-medium text-muted-foreground">Suggested Hashtags</label>
                <div className="flex flex-wrap gap-2">
                  {["#SummerVibes", "#NewDrop", "#FashionTrends", "#OOTD", "#StyleInspo"].map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full border border-blue-500/30 bg-blue-500/10 px-2 py-1 text-xs text-blue-300"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Stats cards */}
              <div className="grid grid-cols-3 gap-2">
                <StatCard label="Engagement" value="94%" color="purple" />
                <StatCard label="Readability" value="A+" color="blue" />
                <StatCard label="SEO Score" value="87" color="cyan" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function SidebarItem({ icon, label, active = false }: { icon: React.ReactNode; label: string; active?: boolean }) {
  return (
    <div
      className={`flex cursor-pointer items-center gap-2 rounded-lg px-3 py-2 text-sm transition-colors ${
        active
          ? "bg-gradient-to-r from-purple-500/20 to-blue-500/20 text-foreground"
          : "text-muted-foreground hover:bg-secondary hover:text-foreground"
      }`}
    >
      {icon}
      <span>{label}</span>
    </div>
  )
}

function StatCard({ label, value, color }: { label: string; value: string; color: "purple" | "blue" | "cyan" }) {
  const colorClasses = {
    purple: "from-purple-500/20 to-purple-500/5 border-purple-500/30",
    blue: "from-blue-500/20 to-blue-500/5 border-blue-500/30",
    cyan: "from-cyan-500/20 to-cyan-500/5 border-cyan-500/30",
  }

  return (
    <div className={`rounded-lg border bg-gradient-to-b p-2 text-center ${colorClasses[color]}`}>
      <div className="text-lg font-bold text-foreground">{value}</div>
      <div className="text-xs text-muted-foreground">{label}</div>
    </div>
  )
}
